﻿namespace Computer
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.PointButton = new System.Windows.Forms.Button();
            this.Equals = new System.Windows.Forms.Button();
            this.Plus = new System.Windows.Forms.Button();
            this.MinusButton = new System.Windows.Forms.Button();
            this.MultiplyButton = new System.Windows.Forms.Button();
            this.DividedButton = new System.Windows.Forms.Button();
            this.RemainButton = new System.Windows.Forms.Button();
            this.Reset = new System.Windows.Forms.Button();
            this.LabelSum = new System.Windows.Forms.Label();
            this.CE = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(57, 327);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(60, 40);
            this.button1.TabIndex = 0;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(123, 327);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(60, 40);
            this.button2.TabIndex = 1;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(191, 327);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(60, 40);
            this.button3.TabIndex = 2;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(57, 281);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(60, 40);
            this.button4.TabIndex = 3;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(123, 281);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(60, 40);
            this.button5.TabIndex = 4;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(191, 281);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(60, 40);
            this.button6.TabIndex = 5;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(57, 235);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(60, 40);
            this.button7.TabIndex = 6;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(123, 235);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(60, 40);
            this.button8.TabIndex = 7;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(191, 235);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(60, 40);
            this.button9.TabIndex = 8;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button0
            // 
            this.button0.Location = new System.Drawing.Point(63, 373);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(120, 40);
            this.button0.TabIndex = 9;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // PointButton
            // 
            this.PointButton.Location = new System.Drawing.Point(191, 373);
            this.PointButton.Name = "PointButton";
            this.PointButton.Size = new System.Drawing.Size(60, 40);
            this.PointButton.TabIndex = 10;
            this.PointButton.Text = "‧";
            this.PointButton.UseVisualStyleBackColor = true;
            this.PointButton.Click += new System.EventHandler(this.PointButton_Click_1);
            // 
            // Equals
            // 
            this.Equals.Location = new System.Drawing.Point(257, 373);
            this.Equals.Name = "Equals";
            this.Equals.Size = new System.Drawing.Size(60, 40);
            this.Equals.TabIndex = 11;
            this.Equals.Text = "＝";
            this.Equals.UseVisualStyleBackColor = true;
            this.Equals.Click += new System.EventHandler(this.Equals_Click);
            // 
            // Plus
            // 
            this.Plus.Location = new System.Drawing.Point(257, 327);
            this.Plus.Name = "Plus";
            this.Plus.Size = new System.Drawing.Size(60, 40);
            this.Plus.TabIndex = 12;
            this.Plus.Text = "＋";
            this.Plus.UseVisualStyleBackColor = true;
            this.Plus.Click += new System.EventHandler(this.Plus_Click);
            // 
            // MinusButton
            // 
            this.MinusButton.Location = new System.Drawing.Point(257, 281);
            this.MinusButton.Name = "MinusButton";
            this.MinusButton.Size = new System.Drawing.Size(60, 40);
            this.MinusButton.TabIndex = 13;
            this.MinusButton.Text = "－";
            this.MinusButton.UseVisualStyleBackColor = true;
            this.MinusButton.Click += new System.EventHandler(this.MinusButton_Click);
            // 
            // MultiplyButton
            // 
            this.MultiplyButton.Location = new System.Drawing.Point(257, 235);
            this.MultiplyButton.Name = "MultiplyButton";
            this.MultiplyButton.Size = new System.Drawing.Size(60, 40);
            this.MultiplyButton.TabIndex = 14;
            this.MultiplyButton.Text = "╳";
            this.MultiplyButton.UseVisualStyleBackColor = true;
            this.MultiplyButton.Click += new System.EventHandler(this.MultiplyButton_Click);
            // 
            // DividedButton
            // 
            this.DividedButton.Font = new System.Drawing.Font("新細明體", 20F);
            this.DividedButton.Location = new System.Drawing.Point(257, 189);
            this.DividedButton.Name = "DividedButton";
            this.DividedButton.Size = new System.Drawing.Size(60, 40);
            this.DividedButton.TabIndex = 15;
            this.DividedButton.Text = "÷";
            this.DividedButton.UseVisualStyleBackColor = true;
            this.DividedButton.Click += new System.EventHandler(this.DividedButton_Click);
            // 
            // RemainButton
            // 
            this.RemainButton.Location = new System.Drawing.Point(191, 189);
            this.RemainButton.Name = "RemainButton";
            this.RemainButton.Size = new System.Drawing.Size(60, 40);
            this.RemainButton.TabIndex = 16;
            this.RemainButton.Text = "％";
            this.RemainButton.UseVisualStyleBackColor = true;
            this.RemainButton.Click += new System.EventHandler(this.RemainButton_Click);
            // 
            // Reset
            // 
            this.Reset.Location = new System.Drawing.Point(123, 189);
            this.Reset.Name = "Reset";
            this.Reset.Size = new System.Drawing.Size(60, 40);
            this.Reset.TabIndex = 17;
            this.Reset.Text = "C";
            this.Reset.UseVisualStyleBackColor = true;
            this.Reset.Click += new System.EventHandler(this.Reset_Click);
            // 
            // LabelSum
            // 
            this.LabelSum.AutoSize = true;
            this.LabelSum.Font = new System.Drawing.Font("新細明體", 30F);
            this.LabelSum.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.LabelSum.Location = new System.Drawing.Point(56, 78);
            this.LabelSum.Name = "LabelSum";
            this.LabelSum.Size = new System.Drawing.Size(0, 40);
            this.LabelSum.TabIndex = 18;
            this.LabelSum.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CE
            // 
            this.CE.Location = new System.Drawing.Point(57, 189);
            this.CE.Name = "CE";
            this.CE.Size = new System.Drawing.Size(60, 40);
            this.CE.TabIndex = 19;
            this.CE.Text = "CE";
            this.CE.UseVisualStyleBackColor = true;
            this.CE.Click += new System.EventHandler(this.CE_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(384, 450);
            this.Controls.Add(this.CE);
            this.Controls.Add(this.LabelSum);
            this.Controls.Add(this.Reset);
            this.Controls.Add(this.RemainButton);
            this.Controls.Add(this.DividedButton);
            this.Controls.Add(this.MultiplyButton);
            this.Controls.Add(this.MinusButton);
            this.Controls.Add(this.Plus);
            this.Controls.Add(this.Equals);
            this.Controls.Add(this.PointButton);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "計算機";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button PointButton;
        private System.Windows.Forms.Button Equals;
        private System.Windows.Forms.Button Plus;
        private System.Windows.Forms.Button MinusButton;
        private System.Windows.Forms.Button MultiplyButton;
        private System.Windows.Forms.Button DividedButton;
        private System.Windows.Forms.Button RemainButton;
        private System.Windows.Forms.Button Reset;
        private System.Windows.Forms.Label LabelSum;
        private System.Windows.Forms.Button CE;
    }
}

